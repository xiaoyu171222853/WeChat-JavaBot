package top.ruojy.wxbot.entity;

import lombok.Getter;
import top.ruojy.wxbot.enums.MessageTypeEnum;

@Getter
public class MessageResponse<T> {
    private MessageTypeEnum messageTypeEnum;
    private T response;
}
