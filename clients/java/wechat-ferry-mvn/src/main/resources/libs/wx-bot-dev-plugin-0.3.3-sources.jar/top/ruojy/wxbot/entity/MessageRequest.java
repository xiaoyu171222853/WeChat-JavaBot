package top.ruojy.wxbot.entity;

import lombok.Getter;
import top.ruojy.wxbot.entity.vo.request.*;
import top.ruojy.wxbot.enums.MessageTypeEnum;

@Getter
public class MessageRequest {

    private final MessageTypeEnum messageTypeEnum;
    private final Object request;

    private MessageRequest(MessageTypeEnum messageTypeEnum, Object request) {
        if (isValidRequestType(messageTypeEnum, request)) {
            throw new IllegalArgumentException("Invalid request type for message type: " + messageTypeEnum);
        }
        this.messageTypeEnum = messageTypeEnum;
        this.request = request;
    }

    public static <T extends WxPpWcfRequest> MessageRequest create(MessageTypeEnum messageType, T request) {
        if (isValidRequestType(messageType, request)) {
            throw new IllegalArgumentException("Invalid request type for message type: " + messageType);
        }
        return new MessageRequest(messageType, request);
    }

    // 校验request类型是否符合messageTypeEnum的要求
    private static boolean isValidRequestType(MessageTypeEnum messageTypeEnum, Object request) {
        switch (messageTypeEnum) {
            case TEXT:
                return !(request instanceof WxPpWcfSendTextMsgReq);
            case EMOJI:
                return !(request instanceof WxPpWcfSendEmojiMsgReq);
            case IMAGE:
                return !(request instanceof WxPpWcfSendImageMsgReq);
            case FILE:
                return !(request instanceof WxPpWcfSendFileMsgReq);
            case RICHTER:
                return !(request instanceof WxPpWcfSendRichTextMsgReq);
            case XML:
                return !(request instanceof WxPpWcfSendXmlMsgReq);
            default:
                return false; // 默认允许其他类型
        }
    }
}


