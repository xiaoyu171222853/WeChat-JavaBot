package top.ruojy.wxbot.entity.vo.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 请求入参-查询-个微WCF数据库SQL查询
 *
 * @author chandler
 * @date 2024-10-02 17:10
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WxPpWcfDatabaseSqlReq extends WxPpWcfRequest {

    /**
     * 数据库名称
     */
    private String databaseName;

    /**
     * SQL语句
     */
    private String sqlText;

}
