package top.ruojy.wxbot.entity.vo.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 请求入参-个微WCF发送XML消息
 *
 * @author chandler
 * @date 2024-10-04 23:11
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WxPpWcfSendXmlMsgReq extends WxPpWcfRequest {

    /**
     * 消息接收人
     * 消息接收人，私聊为 wxid（wxid_xxxxxxxxxxxxxx）
     * 群聊为 roomid（xxxxxxxxxx@chatroom）
     */
    private String recipient;

    /**
     * XML报文内容
     */
    private String xmlContent;

    /**
     * 资源路径-封面图片路径
     */
    private String resourcePath;

    /**
     * xml类型，如：0x21 为小程序
     */
    private Integer xmlType;

}
