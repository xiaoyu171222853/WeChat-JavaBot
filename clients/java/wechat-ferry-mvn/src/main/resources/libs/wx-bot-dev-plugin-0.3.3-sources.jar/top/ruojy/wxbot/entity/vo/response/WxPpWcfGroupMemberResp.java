package top.ruojy.wxbot.entity.vo.response;


import lombok.Data;

/**
 * 请求出参-个微WCF查询群成员
 *
 * @author chandler
 * @date 2024/10/01 21:26
 */
@Data
public class WxPpWcfGroupMemberResp {

    /**
     * 微信内部识别号UID
     * 原始微信账号ID，以"wxid_"开头，初始默认的微信ID=微信号。
     */
    private String weChatUid;

    /**
     * 群内昵称
     */
    private String groupNickName;

    /**
     * 状态
     */
    private String state;

}
