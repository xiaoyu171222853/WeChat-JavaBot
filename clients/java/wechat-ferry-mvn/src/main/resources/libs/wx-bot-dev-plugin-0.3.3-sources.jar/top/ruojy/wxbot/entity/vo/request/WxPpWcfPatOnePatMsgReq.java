package top.ruojy.wxbot.entity.vo.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 请求入参-个微WCF发送拍一拍消息
 *
 * @author chandler
 * @date 2024-10-06 15:50
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WxPpWcfPatOnePatMsgReq extends WxPpWcfRequest {

    /**
     * 消息接收人
     * 消息接收人，私聊为 wxid（wxid_xxxxxxxxxxxxxx）
     * 群聊为 roomid（xxxxxxxxxx@chatroom）
     */
    private String recipient;

    /**
     * 要拍的wxid
     */
    private String patUser;

}
