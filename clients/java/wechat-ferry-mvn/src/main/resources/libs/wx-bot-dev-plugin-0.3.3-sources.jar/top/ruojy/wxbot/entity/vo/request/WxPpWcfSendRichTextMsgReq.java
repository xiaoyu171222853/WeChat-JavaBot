package top.ruojy.wxbot.entity.vo.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 请求入参-个微WCF发送富文本消息
 *
 * @author chandler
 * @date 2024-10-06 15:40
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WxPpWcfSendRichTextMsgReq extends WxPpWcfRequest {

    /**
     * 消息接收人
     * 消息接收人，私聊为 wxid（wxid_xxxxxxxxxxxxxx）
     * 群聊为 roomid（xxxxxxxxxx@chatroom）
     */
    private String recipient;

    /**
     * 左下显示的名字
     */
    private String name;

    /**
     * 填公众号id 可以显示对应的头像（gh_ 开头的）
     */
    private String account;

    /**
     * 标题，最多两行
     */
    private String title;

    /**
     * 摘要，三行
     */
    private String digest;

    /**
     * 点击后跳转的链接
     */
    private String jumpUrl;

    /**
     * 缩略图的链接
     */
    private String thumbnailUrl;

}
