package top.ruojy.wxbot.entity.vo.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 请求入参-查询-个微WCF数据库表查询
 *
 * @author chandler
 * @date 2024-10-02 17:55
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WxPpWcfDatabaseTableReq extends WxPpWcfRequest {

    /**
     * 数据库名称
     */
    private String databaseName;

}
