package top.ruojy.wxbot.entity.vo.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 请求入参-个微WCF发送表情消息
 *
 * @author chandler
 * @date 2024-10-04 23:14
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WxPpWcfSendEmojiMsgReq extends WxPpWcfRequest {

    /**
     * 资源路径-本地表情路径
     */
    private String resourcePath;

    /**
     * 消息接收人
     * 消息接收人，私聊为 wxid（wxid_xxxxxxxxxxxxxx）
     * 群聊为 roomid（xxxxxxxxxx@chatroom）
     */
    private String recipient;

}
