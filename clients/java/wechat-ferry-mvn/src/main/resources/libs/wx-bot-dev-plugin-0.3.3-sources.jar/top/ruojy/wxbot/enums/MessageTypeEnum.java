package top.ruojy.wxbot.enums;

import lombok.Getter;

@Getter
public enum MessageTypeEnum {
    TEXT("文本消息"),
    IMAGE("图片消息"),
    FILE("文件消息"),
    RICHTER("富文本消息"),
    XML("xml消息"),
    EMOJI("emoji");

    final String description;

    MessageTypeEnum(String description) {
        this.description=description;
    }

}
