package top.ruojy.wxbot.entity.vo.request;

public class WxPpWcfRequest {
}
