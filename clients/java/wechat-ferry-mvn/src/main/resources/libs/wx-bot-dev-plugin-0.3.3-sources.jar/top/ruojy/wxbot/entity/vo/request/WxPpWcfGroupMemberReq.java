package top.ruojy.wxbot.entity.vo.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 请求入参-个微WCF查询群成员
 *
 * @author chandler
 * @date 2024-10-02 20:55
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WxPpWcfGroupMemberReq extends WxPpWcfRequest {

    /**
     * 群编号
     */
    private String groupNo;

}
