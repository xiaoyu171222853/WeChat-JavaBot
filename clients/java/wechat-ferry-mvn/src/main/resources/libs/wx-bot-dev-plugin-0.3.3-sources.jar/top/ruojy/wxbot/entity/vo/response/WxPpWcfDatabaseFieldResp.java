package top.ruojy.wxbot.entity.vo.response;


import lombok.Data;

/**
 * 请求出参-个微WCF数据库字段
 *
 * @author chandler
 * @date 2024/10/02 17:15
 */
@Data
public class WxPpWcfDatabaseFieldResp {

    /**
     * 字段类型
     */
    private String type;

    /**
     * 字段
     */
    private String column;

    /**
     * 字段值
     */
    private String value;

}
