package top.ruojy.wxbot.entity.vo.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 请求入参-个微WCF发送图片消息
 *
 * @author chandler
 * @date 2024-10-04 15:55
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WxPpWcfSendImageMsgReq extends WxPpWcfRequest {

    /**
     * 资源路径-本地图片地址
     * 如：`C:/Projs/WeChatRobot/TEQuant.jpeg`
     * 或 `https://raw.githubusercontent.com/lich0821/WeChatFerry/master/assets/TEQuant.jpg`
     */
    private String resourcePath;

    /**
     * 消息接收人
     * 消息接收人，私聊为 wxid（wxid_xxxxxxxxxxxxxx）
     * 群聊为 roomid（xxxxxxxxxx@chatroom）
     */
    private String recipient;

}
